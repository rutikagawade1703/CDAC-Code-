#include <stdio.h>

int main()
{
   int num1 = 100;
   int num2 = 200;
   int result;

   result = num1 + num2;

   printf("Addition of two numbers is : %d\n", result);
   return 0;
}
