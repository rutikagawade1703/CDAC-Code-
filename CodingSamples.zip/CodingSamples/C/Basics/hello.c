#include <stdio.h>

int main()
{
	
	printf("Welcome to C Programming\n");
	printf("Wlcome to Ubuntu\n");
	return 0;
}
