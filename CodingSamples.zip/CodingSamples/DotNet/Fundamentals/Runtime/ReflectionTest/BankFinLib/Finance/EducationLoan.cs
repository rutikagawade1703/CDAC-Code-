namespace Finance;

public class EducationLoan 
{
	[MaxDuration]
	public float Common(decimal amount, int period)
	{
		return 6;
	}

	//expression bodied method
	public float Scholar(decimal amount, int period) => 4;
}

