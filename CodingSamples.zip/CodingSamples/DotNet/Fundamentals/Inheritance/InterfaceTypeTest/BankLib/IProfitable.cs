namespace Banking;

public interface IProfitable
{
    void AddInterest(int months);    
}