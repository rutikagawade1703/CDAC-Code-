SELECT OrderNo, OrderDate, CustomerId, ProductNo, Quantity FROM OrderDetail
