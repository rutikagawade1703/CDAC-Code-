namespace Sales;

public record Order(int Id, int ProductId, int Quantity);