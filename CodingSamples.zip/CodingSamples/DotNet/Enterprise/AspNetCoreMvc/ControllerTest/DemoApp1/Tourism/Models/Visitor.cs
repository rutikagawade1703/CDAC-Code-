namespace Tourism.Models;

public readonly record struct Visitor(string Name, int Visits, DateTime Recent, string Stars);
