//a function can be declared with optional parameters at the end
//of its parameter list along with their default argument values
double Compute(int first, int last, float level = 1);


