//enum type is translated into a class with
//private constructor and static fields 
//of same type corresponding to the members 
//defined in it
enum RiskLevel {
    NONE, LOW, HIGH;
}
