package banking;

public class IllegalTransferException extends RuntimeException {
    
}
