interface InterestRate {
    double forPeriod(int value);
}
